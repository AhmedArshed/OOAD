package Sort;

public class array {
	
	private int count = 0;
	private int arrayValues[] = new int[10];
	
		public void setArray(int value) {
			arrayValues[count] = value;
			count = count + 1;
		}	
		public int[] getArray() {
			return arrayValues;
		}
		public int[] printArray() {
			return arrayValues;
		}
		public void searchArray(int value) {
			for(int i = 0 ; i < 10 ; i++) {
				if(this.arrayValues[i] == value) {
					System.out.println("Value found");
				}
			}
		}
		
		public void sortArray() {
			int n = 10;
			int c, d, swap;
			for (c = 0; c < ( n - 1 ); c++) {
			      for (d = 0; d < n - c - 1; d++) {
			        if (arrayValues[d] > arrayValues[d+1]) /* For descending order use < */
			        {
			          swap = arrayValues[d];
			          arrayValues[d]   = arrayValues[d+1];
			          arrayValues[d+1] = swap;
			        }
			      }
			    }
			  }
		}	
