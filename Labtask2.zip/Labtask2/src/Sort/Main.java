package Sort;
import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		array model = new array();
		Arrayview view = new Arrayview();
		Arraycontroller controller = new Arraycontroller(model, view);
		
		int j = 0;
		while(j == 0) {
			String rno =JOptionPane.showInputDialog("Chose no\n"+"1-Set Array\n"+"2-Get Array\n"+"3-Print Array\n"+"4-search value from array\n"+"5-sort array\n"+"6:End");
			int no = Integer.parseInt(rno);
			if(no == 1) {
				controller.set();
			}
			if(no == 2) {
				controller.get();
			}
			if(no == 3) {
				controller.print();
			}
			if(no == 4) {
				controller.search();
			}
			if(no == 5) {
				controller.sort();
			}
			if(no == 6) {
				break;
			}
		}
	}
}