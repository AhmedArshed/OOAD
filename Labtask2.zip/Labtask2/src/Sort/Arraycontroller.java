package Sort;

public class Arraycontroller {
	private array model;
	private Arrayview view;
	
	public Arraycontroller(array model , Arrayview view) {
		this.model = model;
		this.view = view;
	}
	public void search() {
		model.searchArray(view.svArray());
	}
	public void sort() {
		model.sortArray();
	    System.out.println("Sorted list of numbers:");
	    view.aprint(model.printArray());
	}
	public void print() {
		view.aprint(model.printArray());
	}
	public void get() {
		model.getArray();
	}

	public void set() {
		for(int i = 0 ; i < 10 ; i++) {
			model.setArray(view.contset());
		}
	}
	
}
