package Sort;

import javax.swing.JOptionPane;

public class Arrayview {
	private int value;
	private int a;
	
	public int svArray() {
		String rwo = JOptionPane.showInputDialog("Enter value to search in array");
		value = Integer.parseInt(rwo);
		return value;
	}
	public int contset() {
		String rwo = JOptionPane.showInputDialog("Enter value for array");
		a = Integer.parseInt(rwo);
		return a;
	}
	public void aprint(int arrayValues[]) {
		for(int i = 0 ; i < 10 ; i++) {
			System.out.println (arrayValues[i]);
		}
	}
}
