package pkg;

import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class controler {
	private mode model;
	private login view;
	private connection dbcon;
	private Connection cn;
	public controler(mode model , login view , connection dbcon) {
		this.model = model;
		this.view = view;
		this.dbcon = dbcon;
	}
	/**
	 * making connection with database
	 */
	public void con() {
		cn = dbcon.dbconz();
	}
	/**
	 * calling the desire person that want to get login
	 */
	public void start()
	{
		if(view.start() == 1) {
			model.adminlogin(view.adminlogin() , cn);
		}
		if(view.start() == 2) {
			model.logincheck(view.userlogin() , cn);
		}
	}
}
