package pkg;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField txtuser;
	private JTextField txtpwr;

	/**
	 * Launch the application.
	 */
	public void logincheck() {
		String userid = txtuser.getText();
		String password = txtpwr.getText();
	}
//	public login() {
//		
//	}
	/**
	 * let user decide he/she want to login with user or administrator
	 */
	public int start() {
		String rno =JOptionPane.showInputDialog("Chose no\n"+"1-Login as Admin\n"+"2-Login as User\n");
		int no = Integer.parseInt(rno);
		return no;
	}
	/**
	 * taking values for user to login.
	 */
	public String[] userlogin() {
		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		 LocalDateTime now = LocalDateTime.now();
		String userid;
		String pwr;
		String[] array = null;
		userid = JOptionPane.showInputDialog("Enter you id");
		pwr = JOptionPane.showInputDialog("Enter your password");
		array = new String[]{userid, pwr};
		return array;	
	}
	/**
	 * taking values from administrator to login.
	 */
	public String[] adminlogin() {
		String adminid;
		String pwr;
		String[] array = null;
			adminid = JOptionPane.showInputDialog("Enter you id");
			pwr = JOptionPane.showInputDialog("Enter your password");
			array = new String[]{adminid, pwr};
			return array;
	}
	public void register() {
		
	}
}
