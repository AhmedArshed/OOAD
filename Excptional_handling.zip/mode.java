package pkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.text.AbstractDocument.Content;

import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.xdevapi.PreparableStatement;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime; 

public class mode {
//	private Connection cn;
	Boolean flag = false;
	Boolean flag1 = false;
	private java.sql.Statement s , s1;
	/**
	 * check is the user is valid or invalid. is it's login password is correct or not.This function will store the score of the valid user if he/she is successfully login
	 */
	public void logincheck(String arr[] , Connection cn) {
		String userid;
		String pwr;
		String id;
		userid = arr[0];
		pwr = arr[1];
		ResultSet res , res2 , res3;  
		 
		String querry = "SELECT * FROM student_register WHERE user_id = '"+userid+"'";
		try {
			s = cn.createStatement();
			res = s.executeQuery(querry);
			while(res.next()) {
				id = res.getString("user_id");
				String pas = res.getString("password");
				if(userid.contentEquals(id)) {
					flag = true;
					if(pwr.contentEquals(pas)) {
						System.out.println("Logined");
						System.out.println("Test started");
						String querry2 = "SELECT * FROM tests";
						s1 = cn.createStatement();
						res2 = s1.executeQuery(querry2);
						while(res2.next()) {
							String testid = res2.getString("test_id");
							String name = res2.getString("test_name");
							JOptionPane.showMessageDialog(null, testid);
							JOptionPane.showMessageDialog(null, name);
						}
						String rno =JOptionPane.showInputDialog("Enter test id you want to attempt");
						while(res2.next()) {
							String testid = res2.getString("test_id");
							if(testid.contentEquals(rno)) {
								DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
								 LocalDateTime now = LocalDateTime.now();
								 try {
									 String querry6 = "Select test_time from student_marks where user_id = '"+id+"'";
									 	s = cn.createStatement();
										res3 = s1.executeQuery(querry6);
										while(res3.next()) {
											String time = res2.getString("test_time");
										}
								 }catch (SQLException e) {
									
								 }
								String querry3 = "select question from questions where test_id = '"+rno+"'";
								s = cn.createStatement();
								res2 = s1.executeQuery(querry3);
								while(res2.next()) {
									String qus = res2.getString("question");
									JOptionPane.showMessageDialog(null, qus);
									String a = JOptionPane.showInputDialog(null, "Select T for true and F for false");
									String querry4 = "select * from questions where test_id = '"+rno+"'";
									s = cn.createStatement();
									res3 = s1.executeQuery(querry4);
									while(res3.next()) {
										String correct = res2.getString("correct");
										if(correct.contentEquals(a)) {
											String querry5 = "insert into student_marks (user_id,marks) values('"+userid+"','"+1+"')";
										}
										else {
											String querry5 = "insert into student_marks (user_id,marks) values('"+userid+"','"+0+"')";
										}
									}
								}
							}
						}
					}
					else {
						JOptionPane.showMessageDialog(null,"Wrong password");
					}
				}
			}
			if(flag == false) {
				JOptionPane.showMessageDialog(null,"You have Enter an invild user_id or you are not yet registered");
				String rno =JOptionPane.showInputDialog("Chose no\n"+"1-Get Registered\n"+"2-See tests\n");
				int no = Integer.parseInt(rno);
				if(no == 1) {
					userid = JOptionPane.showInputDialog("Enter you id");
					pwr = JOptionPane.showInputDialog("Enter your password");
					String query = "Insert into student_register value('"+userid+"','"+pwr+"')";
				
					s = cn.createStatement();
					s.execute(query);
				}
				if(no == 2) {
					String querry2 = "SELECT * FROM tests";
					s1 = cn.createStatement();
					res2 = s1.executeQuery(querry2);
					while(res2.next()) {
						String testid = res2.getString("test_id");
						String name = res2.getString("test_name");
						JOptionPane.showMessageDialog(null, testid);
						JOptionPane.showMessageDialog(null, name);
				}
			}
		}
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
	/**
	 * administrator this function checks the valid administrator and then allows him to change the tests if he want's
	 */
	public void adminlogin(String arr[] , Connection cn) {
		String adminid;
		String pwr;
		String id;
		adminid = arr[0];
		pwr = arr[1];
		ResultSet res;
		ResultSet res2;
		String querry = "SELECT * FROM adminlogin WHERE adminid = '"+adminid+"'";
		try {
			s = cn.createStatement();
			res = s.executeQuery(querry);
			while(res.next()) {
				id = res.getString("adminid");
				String pas = res.getString("password");
				if(adminid.contentEquals(id)) {
					flag1 = true;
					if(pwr.contentEquals(pas)) {
						System.out.println("Logined as Admin");
						String rno =JOptionPane.showInputDialog("Chose no\n"+"1-Show tests\n"+"2-Modifi tests\n");
						int no = Integer.parseInt(rno);
						if(no == 1) {
							String querry2 = "SELECT * FROM tests";
								s1 = cn.createStatement();
								res2 = s1.executeQuery(querry2);
								while(res2.next()) {
									String testid = res2.getString("test_id");
									String name = res2.getString("test_name");
									JOptionPane.showMessageDialog(null, testid);
									JOptionPane.showMessageDialog(null, name);
								}
						}
						if(no == 2) {
							String testid;
							String rno3 =JOptionPane.showInputDialog("Enter a test id to change the test");
							String querry3 = "SELECT * FROM tests where test_id ='"+rno3+"'";
							s1 = cn.createStatement();
							res2 = s1.executeQuery(querry3);
							while(res2.next()) {
								testid = res.getString("test_id");
								if(testid.contentEquals(rno3)) {
									String rno4 = JOptionPane.showInputDialog("Enter Changed test name");
									String querry4 = "UPDATE tests SET test_name = '"+rno4+"' WHERE test_id = '"+rno3+"'";
									s1.executeQuery(querry4);
								}
							}
						}
						else {
							System.out.println("You have enter an invalid number");
						}
					}
					else {
						JOptionPane.showMessageDialog(null,"Wrong password");
					}
				}
			}
			if(flag1 == false) {
				JOptionPane.showMessageDialog(null,"You have Enter an invild user_id");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
