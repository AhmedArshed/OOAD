package pkg;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class connection {
		private Connection cn;
		/**
		 * Function use to perform a connection between database.
		 */
		public Connection dbconz() {
			try {
				cn = DriverManager.getConnection("jdbc:mysql://localhost/onlinetest","root","");
				JOptionPane.showMessageDialog(null, "Data Base Connected");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Could Not Connect: \nReason: "+e.getMessage());
			}
			return cn;
		}
	}
