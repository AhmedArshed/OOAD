package pkg;

public class Main {
	/**
	 * main function use to run overall program
	 */
	public static void main(String[] args) {
		mode model = new mode();
		login view = new login();
		connection con = new connection();
		controler controller = new controler(model , view , con);
		controller.con();
		controller.start();
	}
}
