package pkg;

import javafx.beans.property.SimpleStringProperty;

public class StudentModel {
	private SimpleStringProperty Rollno;
    private SimpleStringProperty Name;
    private SimpleStringProperty Father_Name;
    private SimpleStringProperty email;
    private SimpleStringProperty address;
    private SimpleStringProperty gender;
    
    public  StudentModel(String rollno, String name, String fname, String gender, String email, String address) {
        this.Rollno = new SimpleStringProperty(rollno);
        this.Name = new SimpleStringProperty(name);
        this.Father_Name = new SimpleStringProperty(fname);
        this.email = new SimpleStringProperty(gender);
        this.address = new SimpleStringProperty(email);
        this.gender = new SimpleStringProperty(address);
    }
    public String getRollNo() {
        return Rollno.get();
    }

    public String getName() {
        return Name.get();
    }

    public String getFName() {
        return Father_Name.get();
    }

    public String getEmail() {
        return email.get();
    }

    public String getAddress() {
        return address.get();
    }
    public String getgender() {
        return email.get();
    }
    
    public void setRollNo(String rollno) {
        this.Rollno = new SimpleStringProperty(rollno);
    }

    public void setName(String name) {
        this.Name = new SimpleStringProperty(name);
    }

    public void setFName(String fname) {
        this.Father_Name = new SimpleStringProperty(fname);
    }

    public void setGender(String gender) {
        this.gender = new SimpleStringProperty(gender);
    }

    public void setEmail(String email) {
        this.email = new SimpleStringProperty(email);
    }

    public void setAddress(String address) {
        this.address = new SimpleStringProperty(address);
    }
}



