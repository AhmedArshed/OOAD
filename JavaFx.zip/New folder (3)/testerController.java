package pkg;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.scene.control.cell.PropertyValueFactory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import javax.swing.*;
import java.sql.*;

import javax.swing.JOptionPane;

//import com.mysql.cj.xdevapi.Statement;


public class testerController {
	
	private StudentModel model;
	
	private Connection cn;
	@FXML
	private TextField Sname;
	@FXML
	private Button Btnsearch;
	@FXML
    private TableView<StudentModel> infoTbl;
    @FXML
    private TableColumn<StudentModel, String> setrollno;
    @FXML
    private TableColumn<StudentModel, String> setname;
    @FXML
    private TableColumn<StudentModel, String> setfname;
    @FXML
    private TableColumn<StudentModel, String> setgender;
    @FXML
    private TableColumn<StudentModel, String> setemail;
    @FXML
    private TableColumn<StudentModel, String> setaddress;
    
    private ObservableList<StudentModel> dataset;
    
	public void connection() {
		try {
			cn = DriverManager.getConnection("jdbc:mysql://localhost/student","root","");
			JOptionPane.showMessageDialog(null, "Data Base Connected");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Could Not Connect: \nReason: "+e.getMessage());
		}
	}
	
	public void searchdata() {
		String search = Sname.getText();
		JOptionPane.showMessageDialog(null, "search :"+search);
//		model.check_student(search);
	}
	
	@FXML
	public void initialize(){
		String name = Sname.getText();
		connection();
		String query = "SELECT * FROM `studentdetails` WHERE Name = '" + name + "'";
		try {
            dataset = FXCollections.observableArrayList();
            Statement stm = cn.createStatement();
            ResultSet rs = stm.executeQuery(query);

            while (rs.next()) {
                dataset.add(new StudentModel(rs.getString("roll_no"), rs.getString("st_name"), rs.getString("f_name"), rs.getString("gender"), rs.getString("email"), rs.getString("address")));
            }
		} catch (SQLException e) {
            e.printStackTrace();
        }
		setrollno.setCellValueFactory(new PropertyValueFactory<>("RollNo"));
		setname.setCellValueFactory(new PropertyValueFactory<>("Name"));
		setfname.setCellValueFactory(new PropertyValueFactory<>("FName"));
		setgender.setCellValueFactory(new PropertyValueFactory<>("Gender"));
		setemail.setCellValueFactory(new PropertyValueFactory<>("Email"));
		setaddress.setCellValueFactory(new PropertyValueFactory<>("Address"));

        infoTbl.setItems(dataset);
	}
}
