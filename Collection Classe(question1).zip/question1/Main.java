package question1;

import java.util.*;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
//		LinkedList<String> object = new LinkedList<String>();
		
		stack s = new stack();
		Scanner in = new Scanner(System.in);
		while(true){
			System.out.println("Enter 1 to push in stack , 2 to pop in stack and 3 to exit");
			int str = in.nextInt();
			if(str == 1){
				s.push();
				
			}
			if(str == 2){
				s.pop();
			}
			if(str == 3){
				break;
			}
		}
		System.out.println("Queue started");
		queue q = new queue();
		Scanner abc = new Scanner(System.in);
		while(true){
			System.out.println("Enter 1 to Enqueue in queue , 2 to dequeue in stack and 3 to exit");
			
			int str = abc.nextInt();
			if(str == 1){
				q.enqueue();
				
			}
			if(str == 2){
				q.dequeue();
			}
			if(str == 3){
				break;
			}
		}
	}

}
