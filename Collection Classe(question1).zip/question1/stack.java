package question1;

import java.util.LinkedList;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class stack {
	LinkedList<String> object = new LinkedList<String>();
	public void push(){
		int var = object.size();
		if(var == 50){
			System.out.println("overflow");
			return;
		}
		else{
			System.out.println("Enter value to add in stack");
			Scanner in = new Scanner(System.in);
			String str = in.nextLine();
			object.add(str);
		}
	}
	public void pop(){
		int var = object.size();
		if(var == 0){
			System.out.println("underflow");
			return;
		}
		else
			object.removeFirst();
	}
}
