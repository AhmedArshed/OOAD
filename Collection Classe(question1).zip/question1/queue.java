package question1;

import java.util.LinkedList;
import java.util.Scanner;

public class queue {
LinkedList<String> object = new LinkedList<String>();
	public void enqueue(){
		int var = object.size();
		if(var == 50){
			System.out.println("overflow");
			return;
		}
		else{
			System.out.println("Enter value to add in queue");
			Scanner in = new Scanner(System.in);
			String str = in.nextLine();
			object.add(str);
		}
	}
	public void dequeue(){
		int var = object.size();
		if(var == 0){
			System.out.println("underflow");
			return;
		}
		else{
			object.removeLast();
		}
	}
}
