package question2;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class lecture implements person{
	private String name;
	private String email;
	private LinkedList<String> taughtCourses = new LinkedList<String>();
	
	public String getName() {
		Scanner in = new Scanner(System. in);
		System. out. println("Enter a Name");
		String s = in.nextLine();
		name = s;
		return s;
	}
	public String getEmailAddress() {
		Scanner in = new Scanner(System. in);
		System. out. println("Enter a Email");
		String s = in.nextLine();
		return s;
	}
	
	public void displayTaughtCourse() {
		Iterator<String> itr = this.taughtCourses.iterator();
		System.out.println("Displaying course : "+this.getName());	
	}
	public void addCourse(course Course) {
		taughtCourses.add(name);
	}
}
