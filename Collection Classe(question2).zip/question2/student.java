package question2;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class student implements person{
	private LinkedList<course> taughtCourses = new LinkedList<course>();
	public String getName() {
		Scanner in = new Scanner(System. in);
		System. out. println("Enter a Name");
		String s = in.nextLine();
		return s;
	}
	public String getEmailAddress() {
		Scanner in = new Scanner(System. in);
		System. out. println("Enter a Email");
		String s = in.nextLine();
		return s;
	}
	
	public void displayCourses() {
		Iterator<course> itr = this.taughtCourses.iterator();
		System.out.println("courses : "+this.getName());
		while(itr.hasNext()) {
			itr.next().displayCourseInfo();
		}
	}
	public String getId() {
		String id = null;
		Scanner in = new Scanner(System. in);
		System.out.println("Enter id");
		id = in.nextLine();
		return id;
	}
	public void addCourse(course Course) {
		taughtCourses.add(Course);
	}
}
