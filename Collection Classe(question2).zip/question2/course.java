package question2;
import java.util.*;
import java.util.ArrayList;

public class course {
	private LinkedList<student>St;
	private lecture teacher = new lecture();
	private String title;
	student s = new student();
	public void addStudents(student Student){
		St.add(Student);
	}
	public void assignTeacher(lecture t) {
		teacher = t;
	}
	public int getNumberOfStudent() {
		return St.size();
	}
	public void seTitle(String courseTitle) {
		title = courseTitle;
	}
	public lecture getTeacher() {
		return teacher;
	}
	public void displayCourseInfo() {
		System.out.println("Course info "+title+ "");
		System.out.println("no of student "+St.size()+ "");
		System.out.println("teacher name "+teacher+ "");
	}
	public void displayStudent() {
		Iterator<student> itr = St.iterator();
		while (itr.hasNext()){
			
			System.out.println("Name : "+s.getName()+" ID : "+s.getId());
		}
	}
}
