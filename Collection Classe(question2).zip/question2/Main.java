package question2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		course c = new course();
		lecture l = new lecture();
		student s = new student();
		
		//for two courses 
		c.seTitle("English");
		c.seTitle("Urdu");
		//for two lectures
		
		
		//four student
	}

}
