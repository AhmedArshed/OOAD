package question2;

import java.util.Scanner;

interface person {
	public String getName();
	public String getEmailAddress();
}
